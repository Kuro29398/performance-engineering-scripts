@echo off
title PROD vs PERF Config Compare Tool V5
python -c "import yaml" >nul 2>&1 || python -m pip install pyyaml
python "%~dp0yaml_compare_tool_v5.py"
