
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import yaml, csv

IGN = [
    "metadata.managedFields","metadata.creationTimestamp","metadata.resourceVersion",
    "metadata.uid","metadata.selfLink","metadata.generation"
]
EMB = {"application.yml","application.yaml","bootstrap.yml","bootstrap.yaml","config.yml","config.yaml"}

Q = {
    "All":[],
    "Cassandra":["cassandra"],
    "Kafka":["kafka"],
    "Hazelcast":["hazelcast",".hz.","partition-count","backup-count"],
    "Executor":["executor","threadpool","thread-pool"],
    "Probe":["probe","liveness","readiness"],
    "JVM / GC":["jvm","java_opts","xmx","xms","xlog:gc","gc.log","forkjoin","g1reserve","reservepercent"],
    "Parallelism":["parallelism","parallel","forkjoinpool"],
    "WAN":["wan"],
    "Memory":["memory","heap","xmx","xms"],
    "Influx / Metrics":["influx","metric"],
    "Telegraf":["telegraf"],
    "Management Center":["management-center","managementcenter","mancenter"],
    "Windowing":["windowing","window"]
}

NOISE = [
    "bootstrap.servers","bootstrap-servers","group.id","group-id",
    "metadata.namespace","release-namespace","release-name","metadata.name",
    "metadata.labels.app.kubernetes.io/instance","cluster-name","hostname","endpoint"
]

def sc(v):
    if v is None: return "null"
    if isinstance(v, bool): return str(v).lower()
    return str(v)

def ign(p):
    x = p.lower()
    return any(x == i.lower() or x.startswith(i.lower()+".") or x.startswith(i.lower()+"[") for i in IGN)

def flat(d, p=""):
    r = {}
    if isinstance(d, dict):
        for k, v in d.items():
            q = f"{p}.{k}" if p else str(k)
            if ign(q):
                continue
            if isinstance(v, str) and str(k).lower() in EMB:
                try:
                    ds = [x for x in yaml.safe_load_all(v) if x is not None]
                    if ds and all(isinstance(x,(dict,list)) for x in ds):
                        for i, x in enumerate(ds):
                            r.update(flat(x, q if len(ds)==1 else f"{q}.document[{i}]"))
                        continue
                except:
                    pass
            r.update(flat(v, q))
    elif isinstance(d, list):
        named = bool(d) and all(isinstance(x,dict) and "name" in x for x in d)
        if named:
            for x in d:
                b = f"{p}[{x['name']}]"
                for k, v in x.items():
                    if k != "name":
                        r.update(flat(v, f"{b}.{k}"))
        else:
            for i, v in enumerate(d):
                r.update(flat(v, f"{p}[{i}]"))
    elif p and not ign(p):
        r[p] = sc(d)
    return r

def load(p):
    with open(p, encoding="utf-8-sig") as f:
        ds = [x for x in yaml.safe_load_all(f.read()) if x is not None]
    r = {}
    for i, d in enumerate(ds):
        r.update(flat(d, "" if len(ds)==1 else f"document[{i}]"))
    return r

class App:
    def __init__(self, w):
        self.w = w
        w.title("PROD vs PERF Config Compare Tool - V5")
        w.geometry("1580x930")

        self.prod = tk.StringVar()
        self.perf = tk.StringVar()
        self.mode = tk.StringVar(value="Delta Only")
        self.quick = tk.StringVar(value="All")
        self.find = tk.StringVar()
        self.hide_noise = tk.BooleanVar(value=True)
        self.search_values = tk.BooleanVar(value=True)

        self.all_rows = []
        self.view_rows = []

        f = tk.LabelFrame(w, text="Files")
        f.pack(fill="x", padx=10, pady=5)

        for row,(lab,var) in enumerate([("PROD (Baseline):",self.prod),("PERF:",self.perf)]):
            tk.Label(f,text=lab,width=18,anchor="w").grid(row=row,column=0)
            tk.Entry(f,textvariable=var,width=118).grid(row=row,column=1,padx=5)
            tk.Button(f,text="Browse",command=lambda v=var:self.browse(v)).grid(row=row,column=2)

        c = tk.LabelFrame(w, text="Compare / Filters")
        c.pack(fill="x", padx=10, pady=3)

        tk.Button(c,text="Compare",command=self.compare,width=13).grid(row=0,column=0,padx=4)
        ttk.Combobox(c,textvariable=self.mode,values=["Delta Only","Full Validation"],
                     state="readonly",width=17).grid(row=0,column=1,padx=4)
        ttk.Combobox(c,textvariable=self.quick,values=list(Q),state="readonly",
                     width=20).grid(row=0,column=2,padx=4)
        tk.Button(c,text="Apply",command=self.apply).grid(row=0,column=3,padx=4)

        tk.Checkbutton(c,text="Hide environment-specific noise",
                       variable=self.hide_noise,command=self.apply).grid(row=0,column=4,padx=8)
        tk.Checkbutton(c,text="Search inside PROD/PERF values",
                       variable=self.search_values,command=self.apply).grid(row=0,column=5,padx=8)

        tk.Button(c,text="Export CSV",command=self.export).grid(row=0,column=6,padx=4)

        tk.Label(c,text="Custom filter:").grid(row=1,column=0,pady=6)
        e = tk.Entry(c,textvariable=self.find,width=58)
        e.grid(row=1,column=1,columnspan=2,sticky="w")
        e.bind("<KeyRelease>",lambda e:self.apply())
        tk.Button(c,text="Clear Filters",command=self.clear).grid(row=1,column=3)

        tk.Label(
            c,
            text="Searches path + values when enabled. Example: parallel finds ForkJoinPool.common.parallelism=50 inside JAVA_OPTS."
        ).grid(row=1,column=4,columnspan=3,sticky="w")

        self.summary = tk.Label(w,text="PROD is always the baseline.",anchor="w")
        self.summary.pack(fill="x",padx=12,pady=3)

        fr = tk.Frame(w)
        fr.pack(fill="both",expand=True,padx=10)

        self.tree = ttk.Treeview(
            fr, columns=("p","a","b","d","m"), show="headings", height=17
        )
        for col,head,width in [
            ("p","Parameter / Full Path",560),
            ("a","PROD",330),
            ("b","PERF",330),
            ("d","Status / Delta",160),
            ("m","Matched In",140)
        ]:
            self.tree.heading(col,text=head)
            self.tree.column(col,width=width,anchor="w",stretch=True)

        ys = ttk.Scrollbar(fr,orient="vertical",command=self.tree.yview)
        xs = ttk.Scrollbar(fr,orient="horizontal",command=self.tree.xview)
        self.tree.configure(yscrollcommand=ys.set,xscrollcommand=xs.set)
        self.tree.grid(row=0,column=0,sticky="nsew")
        ys.grid(row=0,column=1,sticky="ns")
        xs.grid(row=1,column=0,sticky="ew")
        fr.rowconfigure(0,weight=1)
        fr.columnconfigure(0,weight=1)

        self.tree.bind("<<TreeviewSelect>>",self.show_detail)
        self.tree.bind("<Double-1>",self.popup)

        det = tk.LabelFrame(
            w,
            text="Full Selected Row (click any row — complete values shown here)",
            padx=7,pady=5
        )
        det.pack(fill="x",padx=10,pady=(5,8))

        self.detail = tk.Text(det,height=10,wrap="word",font=("Consolas",10))
        sy = ttk.Scrollbar(det,orient="vertical",command=self.detail.yview)
        self.detail.configure(yscrollcommand=sy.set)
        self.detail.pack(side="left",fill="both",expand=True)
        sy.pack(side="right",fill="y")

        self.detail.insert(
            "1.0",
            "Click a comparison row to see the COMPLETE Parameter, PROD value and PERF value.\n"
            "Double-click a row for a separate resizable popup."
        )
        self.detail.configure(state="disabled")

    def browse(self,var):
        p = filedialog.askopenfilename(
            filetypes=[
                ("Config files","*.yaml *.yml *.txt *.conf *.cfg *.properties"),
                ("All Files","*.*")
            ]
        )
        if p:
            var.set(p)

    def compare(self):
        if not self.prod.get() or not self.perf.get():
            messagebox.showerror("Missing file","Select PROD and PERF files.")
            return
        try:
            a,b = load(self.prod.get()), load(self.perf.get())
        except Exception as e:
            messagebox.showerror("Parse error",str(e))
            return

        self.all_rows = []
        for k in sorted(set(a)|set(b), key=str.lower):
            if k in a and k not in b:
                r=(k,a[k],"","Missing in PERF")
            elif k not in a:
                r=(k,"",b[k],"Added in PERF")
            elif a[k] != b[k]:
                r=(k,a[k],b[k],"Value Changed")
            else:
                r=(k,a[k],b[k],"Same")
            self.all_rows.append(r)

        self.apply()

    def match_locations(self,row,terms):
        if not terms:
            return ""
        path,prod,perf,status = row
        hits=[]
        lp=path.lower()
        lprod=str(prod).lower()
        lperf=str(perf).lower()
        lstatus=status.lower()

        for t in terms:
            if t in lp and "Parameter" not in hits: hits.append("Parameter")
            if self.search_values.get() and t in lprod and "PROD" not in hits: hits.append("PROD")
            if self.search_values.get() and t in lperf and "PERF" not in hits: hits.append("PERF")
            if t in lstatus and "Status" not in hits: hits.append("Status")
        return ", ".join(hits)

    def row_matches_terms(self,row,terms):
        if not terms:
            return True
        path,prod,perf,status = row
        hay = [path.lower(), status.lower()]
        if self.search_values.get():
            hay += [str(prod).lower(), str(perf).lower()]
        return any(any(t in h for h in hay) for t in terms)

    def apply(self):
        self.tree.delete(*self.tree.get_children())
        self.view_rows=[]

        quick_terms=[x.lower() for x in Q[self.quick.get()]]
        custom_terms=[x.strip().lower() for x in self.find.get().split(",") if x.strip()]

        for r in self.all_rows:
            path=r[0].lower()

            if self.mode.get()=="Delta Only" and r[3]=="Same":
                continue
            if self.hide_noise.get() and any(x in path for x in NOISE):
                continue
            if quick_terms and not self.row_matches_terms(r,quick_terms):
                continue
            if custom_terms and not self.row_matches_terms(r,custom_terms):
                continue

            combined_terms = custom_terms if custom_terms else quick_terms
            matched = self.match_locations(r,combined_terms)
            display_row = r + (matched,)
            self.view_rows.append(display_row)
            self.tree.insert("","end",values=display_row)

        n=lambda z:sum(r[3]==z for r in self.view_rows)
        self.summary.config(
            text=f"Displayed: {len(self.view_rows)} | Missing in PERF: {n('Missing in PERF')} | "
                 f"Added in PERF: {n('Added in PERF')} | Value Changed: {n('Value Changed')} | "
                 f"Same: {n('Same')} | Filter: {self.quick.get()}"
        )

    def selected(self):
        q=self.tree.selection()
        if not q:
            return None
        return self.tree.item(q[0],"values")

    def detail_text(self,r):
        return (
            f"PARAMETER / FULL PATH:\n{r[0]}\n\n"
            f"PROD:\n{r[1] if r[1] else '<NOT PRESENT>'}\n\n"
            f"PERF:\n{r[2] if r[2] else '<NOT PRESENT>'}\n\n"
            f"STATUS / DELTA:\n{r[3]}\n\n"
            f"MATCHED IN:\n{r[4] if len(r)>4 and r[4] else '<No active text filter>'}"
        )

    def show_detail(self,e=None):
        r=self.selected()
        if not r:
            return
        self.detail.configure(state="normal")
        self.detail.delete("1.0","end")
        self.detail.insert("1.0",self.detail_text(r))
        self.detail.configure(state="disabled")

    def popup(self,e=None):
        r=self.selected()
        if not r:
            return
        p=tk.Toplevel(self.w)
        p.title("Complete PROD / PERF Value")
        p.geometry("1150x680")
        t=tk.Text(p,wrap="word",font=("Consolas",11),padx=10,pady=10)
        y=ttk.Scrollbar(p,orient="vertical",command=t.yview)
        t.configure(yscrollcommand=y.set)
        t.pack(side="left",fill="both",expand=True)
        y.pack(side="right",fill="y")
        t.insert("1.0",self.detail_text(r))
        t.configure(state="disabled")

    def clear(self):
        self.quick.set("All")
        self.find.set("")
        self.apply()

    def export(self):
        if not self.view_rows:
            return
        p=filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("CSV","*.csv")],
            initialfile="prod_vs_perf_v5_filtered.csv"
        )
        if p:
            with open(p,"w",newline="",encoding="utf-8-sig") as f:
                w=csv.writer(f)
                w.writerow(["Parameter / Full Path","PROD","PERF","Status / Delta","Matched In"])
                w.writerows(self.view_rows)

if __name__=="__main__":
    w=tk.Tk()
    App(w)
    w.mainloop()
