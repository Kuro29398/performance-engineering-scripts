V5 fixes custom filtering inside values.

KEY FIX
-------
V4 searched mainly the parameter path.
V5 can search:
- Parameter / Full Path
- PROD value
- PERF value
- Status

"Search inside PROD/PERF values" is ON by default.

Example:
Custom filter = parallel

This now finds:
-Djava.util.concurrent.ForkJoinPool.common.parallelism=50

even though that text is inside JAVA_OPTS and not in the YAML parameter path.

NEW COLUMN
----------
Matched In:
- Parameter
- PROD
- PERF
- Status

This tells you exactly where the search term was found.

QUICK FILTER IMPROVEMENT
------------------------
Parallelism quick filter now includes:
parallelism
parallel
forkjoinpool

All V4 features remain:
- PROD baseline
- Delta Only / Full Validation
- Quick filters
- Environment noise hiding
- Complete long-value panel
- Double-click popup
- CSV export
